package mergepaises;

public class ProjetoMergePaises {
    
    String veta[] = { "Angola", "Chile", "Grécia", "Itália", "Moçambique", "Portugal",
                      "Rússia", "Suécia" };
    
    String vetb[] = { "Argentina", "Brasil", "Canadá", "Chile", "Dinamarca", "Espanha", 
                      "França", "Inglaterra", "Turquia", "Uruguai", "Zimbawe" };
    
    String res[]; //falta alocar memória para este vetor
    
    public static void main(String[] args) {
       new ProjetoMergePaises();
    }
    
    public ProjetoMergePaises() { //coloquemos aqui a lógica principal
        //executar mergePaises (enviar os vetores)
        //visualizar o vetor final fusionado
    }
    
    public void mergePaises (String a[], String b[], String res[]) {
        int i=0, j=0, k=0;
        
        while( ) { //ciclo para percorrer os vetores a[] e b[] com os ponteiros i e j
            //decidir se pegar um país de a[] ou pegar de b[] e adicionar no vetor res[]
            
            k++; //ponteiro do vetor res[]
        }
        
        while( ) { //ciclo para copiar para res[] os possíveis itens remanescentes que ficaram em a[]     
            
        }
        
        while( ) { //ciclo para copiar para res[] os possíveis itens remanescentes que ficaram em b[]     
            
        }
    }
    
}
