package mergepaises;

public class ProjetoMergePaises {

    String veta[] = { "Angola", "Chile", "Grécia", "Itália", "Moçambique", "Portugal",
            "Rússia", "Suécia" };

    String vetb[] = { "Argentina", "Brasil", "Canadá", "Chile", "Croacia", "Dinamarca", "Espanha",
            "França", "Inglaterra", "Turquia", "Uruguai", "Zimbawe" };

    String res[] = new String[veta.length + vetb.length];

    public static void main(String[] args) {
        new ProjetoMergePaises();
    }

    public ProjetoMergePaises() { 
        mergePaises(veta,vetb,res);
        for(String pais: res){
            System.out.println(pais);
        }
    }

    public void mergePaises(String veta[], String vetb[], String res[]) {
        int i = 0, j = 0, k = 0;
        while (i < veta.length && j < vetb.length) {
            if (veta[i].compareToIgnoreCase(vetb[j]) <= 0) {
                res[k] = veta[i];
                i++;
            } else {
                res[k] = vetb[j];
                j++;
            }
            k++;
        }

        while (i < veta.length) {
            res[k] = veta[i];
            i++;
            k++;
        }

        while (j < vetb.length) {
            res[k] = vetb[j];
            j++;
            k++;
        }

        for (int x = 0; x < res.length; x++) {
            System.out.println(res[x]);
        }
    }

}
